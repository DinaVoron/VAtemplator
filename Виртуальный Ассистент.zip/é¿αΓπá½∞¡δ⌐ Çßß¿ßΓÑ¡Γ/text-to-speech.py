# -*- СИНТЕЗ РЕЧИ | TTS -*- #
import torch
import time
import sounddevice as sd
from console import *

# Настройки
language    = 'ru'
model_id    = 'ru_v3'
device      = torch.device('cpu') # cpu или gpu
# Expected one of cpu, cuda, ipu, xpu, mkldnn, opengl, opencl, ideep, hip, ve, fpga, ort, xla, lazy, vulkan, mps, meta, hpu, mtia, privateuseone device type at start of device string: gpu
speaker     = 'xenia'             # aidar, baya, kseniya, xenia, random
sample_rate = 48000 # 8000, 24000, 48000
put_accent  = True
put_yo      = True

model, _ = torch.hub.load(repo_or_dir = 'snakers4/silero-models',
	model = 'silero_tts',
	language = language,
	speaker = model_id)

model.to(device)

# Реализация : TTS
def speak(message: str):
	Console.INFO(None, "Голосовой помощник начал воспроизведение сообщения.")
	audio = model.apply_tts(text = message + ".",
		speaker = speaker,
		sample_rate = sample_rate,
		put_accent = put_accent,
		put_yo = put_yo)
	Console.message("Воспроизведено", message + ".")
	sd.play(audio, sample_rate * 1.05)
	time.sleep((len(audio) / sample_rate) + 0.5)
	sd.stop()
	Console.INFO(None, "Голосовой помощник завершил воспроизведение сообщения.")

speak("Сам напиши свой текст")