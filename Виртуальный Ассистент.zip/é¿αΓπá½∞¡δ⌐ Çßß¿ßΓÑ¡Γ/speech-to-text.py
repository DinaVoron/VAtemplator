# -*- РАСПОЗНАНИЕ РЕЧИ | STT -*- #
import vosk
import queue
import sys
import json
import sounddevice as sd
from console import *

# Настройки
model        = vosk.Model("model_small")
samplerate   = 16000
device_index = 1

# Глобальные переменные
q = queue.Queue()

# Реализация : STT
def stt_callback(indata, frames, time, status):
	if status:
		print(status, file = sys.stderr)
	q.put(bytes(indata))

def listen():
	Console.INFO(None, "Голосовой помощник начал прослушку сообщения.")
	with sd.RawInputStream(samplerate = samplerate, blocksize = 8000, device = device_index, dtype = 'int16', channels = 1, callback = stt_callback):
		rec = vosk.KaldiRecognizer(model, samplerate)
		f_working = True
		while f_working:
			data = q.get()
			if rec.AcceptWaveform(data):
				# Полное распознавание
				str_res = json.loads(rec.Result())["text"]
				Console.message("Распознано", " " + str_res)
				f_working = False
			else:
				# Неполное (Частичное) распознавание
				Console.message_part("Распознание", json.loads(rec.PartialResult())["partial"])
	Console.INFO(None, "Голосовой помощник завершил прослушку сообщения.")
	return str_res