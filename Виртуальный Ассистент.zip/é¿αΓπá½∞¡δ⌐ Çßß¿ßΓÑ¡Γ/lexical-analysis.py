# -*- ЛЕКСИЧЕСКИЙ АНАЛИЗАТОР | LexAn -*- #
import re

lexer_tokens = [
	('active', r'Кеша')
]





class Token:
	def __init__(self, code, lexem):
		self.code  = code
		self.lexem = lexem

	def __repr__(self):
		return f"{self.code}: {self.lexem}"

class Lexer:
	def __init__(self):
		self.token      = Token('EOF', None)
		self.pos        = 0
		self.data       = []
		self.token_type = lexer_tokens
		self.source     = ""

	def __next_token__(self):
		self.pos += 1
		if self.pos >= len(self.data):
			return Token('EOF', None)
		return self.data[self.pos]

	def __last_token__(self):
		self.pos -= 1
		if self.pos < 0:
			return Token('EOF', None)
		return self.data[self.pos]

	def set_source(self, source):
		self.source = source
		token_reg_ex = '|'.join('(?P<%s>%s)' % it for it in self.token_type)
		for it in re.finditer(token_reg_ex, self.source):
			code  = it.lastgroup
			lexem = it.group(code)

			token = Token(code, lexem)
			self.data.append(token)
		if self.pos < 0:
			return Token('EOF', None)
		if self.pos >= len(self.data):
			return Token('EOF', None)
		self.token =  self.data[self.pos]

	def get_token(self, pos):
		if pos < 0:
			return Token('EOF', None)
		if pos >= len(self.data):
			return Token('EOF', None)
		return self.data[pos]

	def curren_token(self):
		return self.token

	def next_token(self):
		self.token = self.__next_token__()
		return self.token

	def last_token(self):
		self.token = self.__last_token__()
		return self.token