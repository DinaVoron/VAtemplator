import importlib
from console import *                                       # Console | Консоль

# Подготовка к работе
Console.message_part(None, "Подготовка к работе...")
STT = importlib.import_module("speech-to-text")             # listen  | Прослушать
Console.INFO("STT", "  Подготовка завершена.")
Console.message_part(None, "Подготовка к работе...")
TTS = importlib.import_module("text-to-speech")             # speak   | Произнести
Console.INFO("TTS", "  Подготовка завершена.")
# *************************************************************************
Console.message_part(None, "Подготовка к работе...")

lexer = importlib.import_module("lexical-analysis").Lexer() # Lexer   | Лексический анализатор

Console.INFO("Lexer", "Подготовка завершена.")
# *************************************************************************
Console.INFO(None, "Подготовка завершена.")

STT.listen()

