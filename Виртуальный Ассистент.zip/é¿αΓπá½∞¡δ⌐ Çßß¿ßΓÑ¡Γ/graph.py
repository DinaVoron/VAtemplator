# -*- ГРАФ ЗНАНИЙ | Graph -*- #
import networkx as nx
# import matplotlib.pyplot as plt
from pyvis.network import Network
from console import *

# Настройки
height     = "760px"
width      = "100%"
bgcolor    = "#222222"
font_color = "white"

# Глобальные переменные
static_node_id    = 1



# Реализация : Node
class Node:
	def __init__(self, _id, _label, _title, _color, _size, _shape, fl_dynamics):
		self.id          = _id
		self.label       = _label
		self.title       = _title
		self.color       = _color
		self.size        = _size
		self.shape       = _shape
		self.fl_dynamics = fl_dynamics

# Реализация : Edge
class Edge:
	def __init__(self):
		pass

# Реализация : Graph
class Graph:
	def __init__(self):
		# Создание объекта графа
		self.DiGraph = nx.DiGraph()

	def add_node(self, _id, _label, _title, _color = '#97c2fc', _size = 8, _shape = 'sphere', fl_dynamics = True):
		global static_node_id
		if static_node_id == _id:
			self.DiGraph.add_node(Node(_id, _label, _title, _color, _size, _shape, fl_dynamics))
				
			static_node_id += 1
		else:
			Console.ERROR("Граф знаний", f"Неверный идентификатор (Id:{_id}), ожидался (Id:{static_node_id})")

	def add_edge(self, fl_dynamics, label):
		# Edge : Имеет атрибуты :
		# 
		pass

	def visible(self, buttons = False):
		# Отображение графа
		net = Network(height = "760px", width = "100%",
			bgcolor = "#222222", font_color = "white",
			notebook = False, directed = True,
			select_menu = True, filter_menu = True)
		if buttons:
			net.show_buttons()
		else:
			net.set_options("""const options = {
			  "interaction": {
			    "navigationButtons": true
			  }
			}""")

		# net.from_nx(self.DiGraph)
		for it in self.DiGraph.nodes:
			net.add_node(it.id, 
				label = it.label,
				title = it.title,
				color = it.color,
				size  = it.size,
				shape = it.shape)

		net.show('graph.html', notebook=False)






g = Graph()
g.add_node(1, "Hello_1", "1")
g.add_node(2, "Hello_2", "2")
g.add_node(3, "Hello_3", "3")
g.visible()




# for node in net.nodes:
# 	print(node)
# 	node['label'] = 'Hello'
# 	node['shape'] = 'circle'




# nx.draw(
#     DiGraph, pos, edge_color='black', width=1, linewidths=1,
#     node_size=500, node_color='pink', alpha=0.9,
#     labels={node: node for node in DiGraph.nodes()}
# )

# nx.draw(DiGraph, with_labels=True, font_weight='bold')
# plt.show()

# class Node:
# 	def __init__(self):
# 		pass
# 	def __repr__(self):
# 		return "Hello"

# добавление узлов
# net.add_nodes(
#     [1, 2, 3, 4, 5],  # node ids
#     label=['Node #1', 'Node #2', 'Node #3', 'Node #4', 'Node #5'],  # node labels
#     # node titles (display on mouse hover)
#     title=['Main node', 'Just node', 'Just node', 'Just node', 'Node with self-loop'],
#     color=['#d47415', '#22b512', '#42adf5', '#4a21b0', '#e627a3']  # node colors (HEX)
# )

# добавляем тот же список узлов, что и в предыдущем примере
# net.add_edges([(1, 2), (1, 3), (2, 3), (2, 4), (3, 5), (5, 5)])



# nx_graph = nx.cycle_graph(10)

# nx_graph.nodes[1]['title'] = 'Number 1'
# nx_graph.nodes[1]['group'] = 1
# nx_graph.nodes[3]['title'] = 'I belong to a different group!'
# nx_graph.nodes[3]['group'] = 10

# nx_graph.add_node(11, size=20, title='couple', group=2)
# nx_graph.add_node(12, size=15, title='couple', group=2)
# nx_graph.add_edge(9, 12, weight=5)
# nx_graph.add_node(25, size=25, label='lonely', title='lonely node', group=3)

# nt = Network('500px', '500px') # , notebook=True

# nt.from_nx(nx_graph)
# nt.show('nx.html', notebook=False)